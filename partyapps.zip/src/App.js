import './App.css';
import FirstSection from './component/section';


function App() {
  return (
    <div className="App">
        <FirstSection/>
    </div>
  );
}

export default App;
